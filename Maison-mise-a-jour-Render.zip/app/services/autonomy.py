"""Progressive autonomy is separate from TEST/LIVE and the server send lock."""
import secrets
import time
from sqlalchemy import select
from app.core.tenancy import manager_identity, organization_id
from app.db.models import ManagerWorkspace, AuditLog, Membership

LEVELS=('observe','assisted','auto_safe','full_auto')
LABELS={'observe':'Observation','assisted':'Validation humaine','auto_safe':'Automatique prudent','full_auto':'Automatique avec escalade'}

class AutonomyService:
    def __init__(self,db,vault):self.db,self.vault=db,vault
    def get(self):
        with self.db.session() as session:
            row=session.get(ManagerWorkspace,'autonomy')
            return self.vault.decrypt(row.encrypted_data).get('level','observe') if row else 'observe'
    def actor(self):
        identity=manager_identity()
        if not identity:raise PermissionError('Session Owner/Admin requise.')
        with self.db.system_session() as session:
            member=session.get(Membership,(organization_id(),identity['user_id']))
            if not member or member.role not in {'owner','admin'}:raise PermissionError('Seul un Owner/Admin peut modifier l’autonomie.')
        return identity['user_id']
    async def set(self,level,confirmation=None):
        actor=self.actor()
        if level not in LEVELS:raise ValueError('Niveau d’autonomie inconnu.')
        async with self.db.lock('autonomy'):
            old=self.get()
            with self.db.session() as session:
                pending=session.get(ManagerWorkspace,'autonomy:pending')
                if LEVELS.index(level)>LEVELS.index(old):
                    data=self.vault.decrypt(pending.encrypted_data) if pending else {}
                    if not confirmation:
                        token=secrets.token_urlsafe(24)
                        data={'level':level,'actor':actor,'old':old,'token':token,'expires':time.time()+900}
                        if not pending:pending=ManagerWorkspace(id='autonomy:pending');session.add(pending)
                        pending.encrypted_data=self.vault.encrypt(data);session.commit()
                        return {'status':'pending_autonomy','autonomy':level,'confirmation':token,
                            'message':'Passer à « '+LABELS[level]+' » ? Ce niveau augmente l’autonomie. TEST MODE et le verrou serveur restent prioritaires ; aucun ancien aperçu ne sera envoyé.'}
                    if data.get('level')!=level or data.get('actor')!=actor or data.get('old')!=old or data.get('expires',0)<time.time() or not secrets.compare_digest(data.get('token',''),confirmation):
                        raise ValueError('Confirmation expirée ou invalide.')
                row=session.get(ManagerWorkspace,'autonomy')
                if not row:row=ManagerWorkspace(id='autonomy');session.add(row)
                row.encrypted_data=self.vault.encrypt({'level':level})
                if pending:session.delete(pending)
                session.add(AuditLog(source='manager:autonomy',encrypted_change=self.vault.encrypt({'old':old,'new':level,'actor':actor})))
                session.commit()
        return {'status':'applied','message':'Autonomie : '+LABELS[level]+'. Les sécurités TEST/LIVE restent inchangées.','autonomy':level}

    def automatic_allowed(self,reply):
        level=self.get()
        return level=='full_auto' or level=='auto_safe' and not reply.escalation_required
