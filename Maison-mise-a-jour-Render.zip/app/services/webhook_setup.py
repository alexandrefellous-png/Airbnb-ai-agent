"""Explicit manager operation: subscribe incoming events, never send guest messages."""
import base64
from urllib.parse import urlsplit
import httpx
from sqlalchemy import select
from app.core.tenancy import organization_id
from app.db.models import AuditLog, GuestyConnection
from app.guesty.auth import TokenService
from app.guesty.errors import GuestyError


class WebhookSetupError(ValueError):
    pass


async def activate_webhook(db, vault, settings, http):
    base = settings.public_base_url.rstrip('/')
    parts = urlsplit(base)
    if parts.scheme != 'https' or not parts.hostname or parts.hostname in {'localhost','127.0.0.1','::1'} or parts.path or parts.query or parts.fragment or parts.username or parts.password or parts.port not in {None,443}:
        raise WebhookSetupError('Ouvrez Maison sur Render. Une adresse publique HTTPS est requise.')
    target = base + '/guesty/webhook/' + organization_id()
    event = 'reservation.messageReceived'
    async with db.lock('guesty_configuration'):
        with db.session() as session:
            connection = session.scalar(select(GuestyConnection).where(GuestyConnection.enabled.is_(True)))
            if not connection:
                raise WebhookSetupError('Connectez d’abord Guesty dans Mes outils.')
        try:
            token = await TokenService(settings, db, vault, http).get()
        except GuestyError:
            raise WebhookSetupError('Guesty refuse la connexion. Vérifiez le Client ID et le Client Secret dans Mes outils.') from None
        headers = {'Authorization':'Bearer '+token,'Accept':'application/json'}

        async def request(method, path, **kwargs):
            # This administrative client can only list/create subscriptions and fetch their key.
            assert (method, path) in {('GET','/webhooks'),('POST','/webhooks'),('GET','/webhooks-v2/secret')}
            try:
                response = await http.request(method, 'https://open-api.guesty.com/v1'+path, headers=headers, **kwargs)
            except httpx.HTTPError:
                raise WebhookSetupError('Guesty ne répond pas. Réessayez : les abonnements seront vérifiés avant toute nouvelle création.') from None
            if response.status_code not in {200,201}:
                raise WebhookSetupError('Guesty a refusé la configuration (HTTP '+str(response.status_code)+'). Aucun message voyageur envoyé.')
            try:
                return response.json()
            except ValueError:
                raise WebhookSetupError('Réponse Guesty illisible. Réessayez pour vérifier l’abonnement existant.') from None

        data = await request('GET','/webhooks')
        rows = data if isinstance(data,list) else data.get('results',data.get('data')) if isinstance(data,dict) else None
        if not isinstance(rows,list) or any(not isinstance(row,dict) or not isinstance(row.get('url'),str) for row in rows):
            raise WebhookSetupError('Impossible de vérifier les abonnements Guesty. Aucune création effectuée.')
        matches = [row for row in rows if row['url']==target]
        if len(matches)>1:
            raise WebhookSetupError('Plusieurs abonnements existent pour cette URL. Vérification nécessaire avant activation.')
        created = not matches
        if created:
            await request('POST','/webhooks',json={'url':target,'events':[event]})
        elif event not in matches[0].get('events',[]):
            raise WebhookSetupError('Un abonnement existe à cette URL mais ne reçoit pas les messages. Il doit être vérifié avant modification.')
        data = await request('GET','/webhooks-v2/secret',params={'url':target})
        secret = data.get('secret') if isinstance(data,dict) else data if isinstance(data,str) else None
        try:
            if not isinstance(secret,str) or not secret.startswith('whsec_') or len(base64.b64decode(secret[6:],validate=True))<16:
                raise ValueError()
        except ValueError:
            raise WebhookSetupError('Abonnement trouvé, mais secret de signature non reconnu. Aucune clé existante remplacée.') from None
        with db.session() as session:
            row = session.scalar(select(GuestyConnection).where(GuestyConnection.enabled.is_(True)))
            credentials = vault.decrypt(row.encrypted_credentials)
            credentials['guesty_webhook_secret'] = secret
            row.encrypted_credentials = vault.encrypt(credentials)
            session.add(AuditLog(source='settings:webhook:auto',encrypted_change=vault.encrypt({'url':target,'event':event,'created':created,'signature_secret_updated':True})))
            session.commit()
        return {'message':'Réception des messages activée. Le secret est enregistré ; le mode de l’agent reste inchangé.','url':target,'created':created}
