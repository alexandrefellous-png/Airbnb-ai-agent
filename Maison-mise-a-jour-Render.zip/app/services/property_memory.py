"""Tenant-scoped natural property lookup and readable, source-backed answers."""
import re
from difflib import SequenceMatcher
from sqlalchemy import select
from app.db.models import Property, PropertyAccess, PropertyWifi, PropertyState
from app.services.knowledge import KnowledgeService
from app.services.local_manager import norm

LABELS = {'name':'Logement','address':'Adresse','timezone':'Fuseau horaire','check_in':'Arrivée','check_out':'Départ',
    'capacity':'Capacité','bedrooms':'Chambres','beds':'Lits','bathrooms':'Salles de bain','floor':'Étage','stairs':'Escalier',
    'door':'Porte','street_instructions':'Chemin d’accès','building_code':'Code immeuble','lockbox_code':'Code de la boîte à clés',
    'lockbox_location':'Emplacement de la boîte à clés','wifi_network':'Réseau Wi-Fi','wifi_password':'Mot de passe Wi-Fi',
    'wifi_router_location':'Emplacement de la box','elevator':'Ascenseur','air_conditioning':'Climatisation',
    'water_heater_location':'Ballon d’eau chaude','electrical_panel_location':'Tableau électrique',
    'access_video':'Vidéo d’accès','access_photos':'Photos d’accès','arrival_guide':'Guide d’arrivée',
    'trash_location':'Poubelles','house_manual':'Manuel','house_rules':'Règles du logement','parking_instructions':'Stationnement',
    'early_checkin_policy':'Arrivée anticipée','late_checkout_policy':'Départ tardif','luggage_policy':'Bagages',
    'aliases':'Autres noms','airbnb_listing_id':'Identifiant Airbnb','guesty_listing_id':'Identifiant Guesty'}

def compact(value):return re.sub(r'[^a-z0-9]','',norm(value))
def words(value):return set(re.findall(r'[a-z0-9]+',norm(value)))

class PropertyLookupError(ValueError):pass

def resolve_property(session, query):
    if not query:raise PropertyLookupError('De quel logement parlez-vous ?')
    key=compact(query);scored=[]
    for p in session.scalars(select(Property).where(Property.archived_at.is_(None))):
        aliases=[p.name,p.guesty_name,p.guesty_listing_id,p.id,*p.onboarding_data.get('aliases',[])]
        aliases+=[p.facts.get('airbnb_listing_id')]
        keys=[compact(v) for v in aliases if isinstance(v,str) and v]
        score=1.0 if key in keys else 0
        if not score:
            # A full internal name in a natural question is a strong explicit reference.
            score=.98 if any(len(k)>=4 and re.search(re.escape(k)+r'(?![0-9])',key) for k in keys) else 0
        if not score and p.address:
            aw=words(p.address);qw=words(query);numbers={w for w in aw if w.isdigit()}
            if numbers & qw and len(aw & qw)>=3:score=.92
            elif compact(p.address)==key:score=1.0
        if not score and len(key)>=4:
            score=max((SequenceMatcher(None,key,k).ratio() for k in keys),default=0)
        if score>=.82:scored.append((score,p))
    scored.sort(key=lambda pair:pair[0],reverse=True)
    if not scored:raise PropertyLookupError('Je ne reconnais pas ce logement. Précisez son nom ou son adresse.')
    if scored[0][0]==1 and (len(scored)==1 or scored[1][0]<1):return scored[0][1]
    if len(scored)>1 and scored[0][0]-scored[1][0]<.08:
        raise PropertyLookupError('Vous parlez de '+ ' ou de '.join(p.name for _,p in scored[:4])+' ?')
    return scored[0][1]

def requested_fields(query):
    q=norm(query or '')
    if re.search(r'tout|infos|informations|que.*sais|fiche',q):return []
    if re.search(r'wifi|wi-fi|wi fi',q):return ['wifi_network','wifi_password','wifi_router_location']
    if 'video' in q:return ['access_video']
    if 'photo' in q:return ['access_photos']
    if 'code' in q:
        return ['building_code'] if re.search(r'immeuble|batiment|digicode',q) else ['lockbox_code','building_code'] if 'codes' in q else ['lockbox_code']
    if re.search(r'rentr|acces|entrer|cles|clefs',q):return ['address','street_instructions','floor','stairs','door','lockbox_location','building_code','lockbox_code','access_video']
    for key,pattern in [('elevator','ascenseur'),('air_conditioning','clim'),('water_heater_location','ballon|chauffe.eau'),('floor','etage'),('trash_location','poubelle')]:
        if re.search(pattern,q):return [key]
    return []

class PropertyMemory:
    def __init__(self,db,vault):self.db,self.vault=db,vault;self.knowledge=KnowledgeService(vault)

    def values(self,session,prop):
        result={**prop.facts,**prop.rules,'name':prop.name,'address':prop.address,'timezone':prop.timezone,
            'check_in':prop.check_in,'check_out':prop.check_out,'guesty_listing_id':prop.guesty_listing_id}
        for model in (PropertyAccess,PropertyWifi):
            row=session.get(model,prop.id)
            if row:result.update(self.vault.decrypt(row.encrypted_data))
        result.update({k:v['value'] for k,v in self.knowledge.effective(self.knowledge.rows(session,prop.id)).items() if not k.startswith('state:')})
        return result

    def answer(self,session,prop,fields=None,missing=False):
        from app.services.onboarding import OnboardingService
        values=self.values(session,prop)
        if missing:
            questions=OnboardingService(self.vault).progress(session,prop)['questions']
            return 'Pour '+prop.name+' :\n'+ ('\n'.join(q['question'] for q in questions) if questions else 'Les informations essentielles sont renseignées. Posez-moi une question pour vérifier un point précis.')
        def display(value):
            if isinstance(value,bool):return 'Oui' if value else 'Non'
            if isinstance(value,list):return ', '.join(map(str,value))
            if isinstance(value,dict):return '; '.join(str(k)+': '+str(v) for k,v in value.items())
            return str(value)
        keys=fields or [k for k,v in values.items() if v is not None and v!='' and v!=[]]
        lines=[LABELS.get(k,k.replace('_',' ').capitalize())+' : '+(display(values[k]) if values.get(k) is not None and values.get(k)!='' else 'Je n’ai pas cette information.') for k in keys]
        if not fields:
            import time
            for row in session.scalars(select(PropertyState).where(PropertyState.property_id==prop.id)):
                if row.valid_from<=time.time() and (row.valid_until is None or row.valid_until>time.time()):
                    lines.append('État actuel — '+LABELS.get(row.key,row.key)+' : '+{'working':'fonctionne','out_of_order':'en panne','unavailable':'indisponible','scheduled':'intervention prévue'}.get(row.status,row.status))
            lines += ['Note : '+self.vault.decrypt(note) for note in prop.notes]
        return prop.name+'\n'+'\n'.join(lines)
