"""Validated rules and corrected examples reuse the existing encrypted tenant stores."""
import re
import time
import uuid
from difflib import unified_diff
from sqlalchemy import select, func
from app.db.models import ManagerWorkspace, ResponseFeedback, AIObservation, SentMessage, AuditLog, HumanStyleExample
from app.core.security import nested_strings
from app.services.local_manager import norm

def category(text):
    q=norm(text)
    for name,pattern in [('early_check_in',r'early|arriv.*tot|check.?in'),('late_check_out',r'late|depart.*tard|checkout|check.out'),
        ('access',r'key|box|code|cles|entrer|access'),('wifi',r'wi.?fi|internet'),('luggage',r'luggage|bagage'),
        ('financial',r'refund|rembours|discount'),('equipment',r'elevator|ascenseur|clim|hot water|chauff')]:
        if re.search(pattern,q):return name
    return 'general'

class BusinessMemory:
    def __init__(self,db,vault):self.db,self.vault=db,vault

    def rules(self,property_id=None,include_proposed=False):
        with self.db.session() as session:
            rows=[{'id':r.id,**self.vault.decrypt(r.encrypted_data)} for r in session.scalars(select(ManagerWorkspace).where(ManagerWorkspace.id.like('rule:%')))]
        return [r for r in rows if (include_proposed or r.get('status')=='active') and (r.get('property_id') is None or r['property_id']==property_id)]

    def save_rule(self,instruction,property_id=None,source='manager',evidence=None):
        if not instruction or len(instruction)>8000:raise ValueError('Précisez une règle de moins de 8 000 caractères.')
        for existing in self.rules(property_id,True):
            if existing.get('instruction')==instruction and existing.get('property_id')==property_id:return existing
        rule={'instruction':instruction,'category':category(instruction),'property_id':property_id,'source':source,
              'confidence':1 if source=='manager' else .7,'status':'active' if source=='manager' else 'proposed',
              'evidence':evidence,'created_at':time.time()}
        key='rule:'+uuid.uuid4().hex
        with self.db.session() as session:
            session.add(ManagerWorkspace(id=key,encrypted_data=self.vault.encrypt(rule)))
            session.add(AuditLog(property_id=property_id,source='learning:rule',encrypted_change=self.vault.encrypt({'rule_id':key,**rule})))
            session.commit()
        return {'id':key,**rule}

    def confirm_rule(self,key):
        from app.core.tenancy import manager_identity
        identity=manager_identity()
        if not identity or identity['role'] not in {'owner','admin','manager'}:raise PermissionError('Session manager requise.')
        with self.db.session() as session:
            row=session.get(ManagerWorkspace,key) if key.startswith('rule:') else None
            if not row:raise ValueError('Règle introuvable.')
            rule=self.vault.decrypt(row.encrypted_data)
            if rule.get('status')!='proposed':raise ValueError('Cette règle a déjà été traitée.')
            rule.update(status='active',confidence=1,source='manager_confirmation',confirmed_by=identity['user_id'])
            row.encrypted_data=self.vault.encrypt(rule)
            session.add(AuditLog(property_id=rule.get('property_id'),source='learning:rule',encrypted_change=self.vault.encrypt({'rule_id':key,**rule})))
            session.commit()
        return {'status':'applied','message':'Règle validée : '+rule['instruction'],'manager_private':True}

    def examples(self,property_id,messages,limit=4):
        query=' '.join(messages);intent=category(query);tokens=set(re.findall(r'\w+',norm(query)))
        with self.db.session() as session:
            rows=session.scalars(select(ResponseFeedback).where(ResponseFeedback.property_id==property_id,
                ResponseFeedback.kind.in_(['correct','manual']),ResponseFeedback.status=='validated').order_by(ResponseFeedback.created_at.desc()).limit(200)).all()
            human_ids=set(session.scalars(select(HumanStyleExample.source_id).where(HumanStyleExample.validated.is_(True))))
            ranked=[]
            from app.services.properties import PropertyService
            secrets=PropertyService(self.db,self.vault).secrets(session)
            for row in rows:
                if row.id not in human_ids:continue
                observation=session.get(AIObservation,row.observation_id)
                if not observation:continue
                received=self.vault.decrypt(row.encrypted_received)
                text=' '.join(received)
                overlap=len(tokens & set(re.findall(r'\w+',norm(text))))
                score=(5 if category(text)==intent and intent!='general' else 0)+overlap
                if not score:continue
                context=self.vault.decrypt(observation.encrypted_context)
                old_values=nested_strings({k:context.get(k,{}) for k in ['access','wifi','property_facts']})
                def safe(body):
                    body=self.vault.redact(body,[*secrets,*[v for v in old_values if len(v)>2]])
                    return re.sub(r'\b\d+(?:[.,:]\d+)?\s*(?:€|EUR|h|pm|am)?','[VALEUR À VÉRIFIER]',body)
                corrected=self.vault.decrypt(row.encrypted_corrected)
                ranked.append((score,row.created_at,{'id':row.id,'category':category(text),'question':safe(text),
                    'validated_response':safe(corrected),'source':'human_correction','facts_authoritative':False}))
            ranked.sort(key=lambda r:(r[0],r[1]),reverse=True)
            return [r[2] for r in ranked[:limit]]

    def recent(self,limit=12):
        with self.db.session() as session:
            rows=session.scalars(select(AuditLog).where(AuditLog.source.in_(['manager:update_fields','manager:confirmed','learning:rule','style:preferences','training:correct','training:manual'])).order_by(AuditLog.created_at.desc()).limit(limit)).all()
            return [{'date':r.created_at,'source':r.source,'property_id':r.property_id,'change':self.vault.decrypt(r.encrypted_change)} for r in rows]

    def remember_feedback(self,feedback_id):
        with self.db.session() as session:
            row=session.get(ResponseFeedback,feedback_id)
            if not row:return
            original=self.vault.decrypt(row.encrypted_original);corrected=self.vault.decrypt(row.encrypted_corrected)
            observation=session.get(AIObservation,row.observation_id)
            context=self.vault.decrypt(observation.encrypted_context)
            metadata={'feedback_id':row.id,'property_id':row.property_id,'reservation_id':observation.reservation_id,
                'language':context.get('language','unknown'),'category':category(' '.join(self.vault.decrypt(row.encrypted_received))),
                'diff':'\n'.join(unified_diff(original.splitlines(),corrected.splitlines(),lineterm='')),'created_at':row.created_at}
            key='feedback:'+row.id.replace('-','')
            if not session.get(ManagerWorkspace,key):session.add(ManagerWorkspace(id=key,encrypted_data=self.vault.encrypt(metadata)))
            session.commit()
        # A corrected answer is evidence, not an automatic financial permission.
        if re.search(r'early|late|€|EUR|manager|availability|disponibil',corrected,re.I):
            self.save_rule(corrected,row.property_id,'correction',feedback_id)

    def metrics(self):
        with self.db.session() as session:
            observations=list(session.scalars(select(AIObservation)))
            feedback=list(session.scalars(select(ResponseFeedback).order_by(ResponseFeedback.created_at)))
            latest={f.observation_id:f.kind for f in feedback};reviewed=len(latest)
            approved=sum(v=='approve' for v in latest.values());edited=sum(v in {'correct','manual'} for v in latest.values())
            contexts=[self.vault.decrypt(o.encrypted_context) for o in observations]
            latencies=[c['generation_seconds'] for c in contexts if c.get('generation_seconds') is not None]
            confidences=[c['reply_confidence'] for c in contexts if c.get('reply_confidence') is not None]
            rules=[self.vault.decrypt(r.encrypted_data) for r in session.scalars(select(ManagerWorkspace).where(ManagerWorkspace.id.like('rule:%')))]
            escalated=sum(bool(self.vault.decrypt(o.encrypted_escalation)) for o in observations)
            return {'active_rules':sum(r.get('status')=='active' for r in rules),'proposed_rules':sum(r.get('status')=='proposed' for r in rules),
                'average_generation_seconds':sum(latencies)/len(latencies) if latencies else None,
                'average_declared_confidence':sum(confidences)/len(confidences) if confidences else None,
                'reviewed':reviewed,'approval_rate':approved/reviewed if reviewed else None,
                'edited_rate':edited/reviewed if reviewed else None,'corrections':sum(f.kind in {'correct','manual'} for f in feedback),
                'escalation_rate':escalated/len(observations) if observations else None,
                'automatic_responses':session.scalar(select(func.count()).select_from(SentMessage).where(SentMessage.status=='sent')),
                'responses':len(observations)}
